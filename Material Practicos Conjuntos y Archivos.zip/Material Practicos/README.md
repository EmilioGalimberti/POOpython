## Archivo de números

Del archivo [numeros.txt](./numeros.txt) que contiene un número entero por cada línea, generar un conjunto que contenga todos los números del archivo y desde el conjunto calcular e informar:
 * Cantidad de números no repetidos
 * Suma de todos los números
 * Cantidad de impares
 * Promedio de pares 


